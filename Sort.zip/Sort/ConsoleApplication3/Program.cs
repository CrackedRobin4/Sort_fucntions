﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    
    class Program
    {

        public static void QuickSort(int[] array)
        {
            QuickSort(array, 0, array.Length - 1);
        }
        public static void QuickSort (int[] array, int left, int right)
        {
            int i = left, j = right;
            int pivot = array[(left + right) >> 1];

            while (i <= j)
            {
                while (array[i] < pivot)
                {
                    i++;
                }

                while (array[j] > pivot)
                {
                    j--;
                }

                if (i <= j)
                {
                    // Swap
                    int tmp = array[i];
                    array[i] = array[j];
                    array[j] = tmp;

                    i++;
                    j--;
                }
            }

            // Recursive calls
            if (left < j)
            {
                QuickSort(array, left, j);
            }

            if (i < right)
            {
                QuickSort(array, i, right);
            }
        }
           
        
        static void Main(string[] args)
        {
                       
            Console.WriteLine("Алгоритм быстрой сортировки");

            int[] array = {1, -2, 3, -5, 11, 2, 33, 12, 43, -1, -1, -1, 122, 233, -53, -90, 90, 12, -21 -2, -4, 145, 1294, -0, 0, -1, 0, 12, 443, 9, -25, -12, -115, 90, -226, 13, 10, -12, -102, -332, 120, 112, 443, -198, 1123};

            array = MyQuickSort.QuickSort(array);

            for (int i = 0; i < array.Length; i++)
            {
                Console.WriteLine(array[i]);
            }

        }
    }
}
