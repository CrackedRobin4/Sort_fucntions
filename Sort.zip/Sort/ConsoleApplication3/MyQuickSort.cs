using System;

namespace ConsoleApplication3
{
    public class MyQuickSort
    {
        public static int[] QuickSort(int[] array)
        {
            if (array.Length <= 1)
            {
                return array;
            }
            else
            {
                int pivotIndex = new Random().Next() % array.Length;
                int pivot = array[pivotIndex];
                int[] left = new int[array.Length];
                int l = 0;
                int[] right = new int[array.Length];
                int r = 0;
                int count = 0;
                for (int i = 0; i < array.Length; i++)
                {
                    if (i == pivotIndex)
                    {
                        continue;
                    }
                    if (array[i] <= pivot)
                    {
                        left[l] = array[i];
                        l++;
                    }
                    else
                    {
                        right[r] = array[i];
                        r++;
                    }
                }
                Array.Resize(ref left, l);
                Array.Resize(ref right, r);
                left = QuickSort(left);
                right = QuickSort(right);
                for (int i = 0; i < left.Length; i++)
                {
                    array[count] = left[i];
                    count++;
                }

                array[count] = pivot;
                count++;
                for (int i = 0; i < right.Length; i++)
                {
                    array[count] = right[i];
                    count++;
                }

                return array;
            }
            
        }
    }
}