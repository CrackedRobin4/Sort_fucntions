﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MergeSort
{
    class Program
    {
        static public void MergeSort(int[] items)
        {
            // Если массив содержит один элемент - прервать выполнение метода  
            
            if (items.Length <= 1)
            {
                return;
            }

            // 

            int leftSize = items.Length / 2;
            int rightSize = items.Length - leftSize;
            int[] left = new int[leftSize];
            int[] right = new int[rightSize];

            Array.Copy(items, 0, left, 0, leftSize);
            Array.Copy(items, leftSize, right, 0, rightSize);

            // Рекурсивное деление массива

            MergeSort(left);   
            MergeSort(right);

            Merge(items, left, right);

        }

        static private void Merge(int[] items, int[] left, int[] right)
        {
            int leftIndex = 0;
            int rightIndex = 0;
            int targetIndex = 0;
            int remaining = left.Length + right.Length; // общая длинна правой и левой части сортируемого массива

            while (remaining > 0)
            {
                if (leftIndex >= left.Length)
                {
                    items[targetIndex] = right[rightIndex++];
                }

                else if (rightIndex >= right.Length)
                {
                    items[targetIndex] = left[leftIndex++];
                }

                else if (left[leftIndex].CompareTo(right[rightIndex]) < 0)
                {
                    items[targetIndex] = left[leftIndex++];
                }

                else
                {
                    items[targetIndex] = right[rightIndex++];
                }

                targetIndex++;
                remaining--;
            }
        }

        static void Main(string[] args)
        {
           
            // Создание массива
            
            int[] array = {1, -2, 3, -5, 11, 2, 33, 12, 43, -1, -1, -1, 122, 233, -53, -90, 90, 12, -21 -2, -4, 145, 1294, -0, 0, -1, 0, 12, 443, 9, -25, -12, -115, 90, -226, 13, 10, -12, -102, -332, 120, 112, 443, -198, 1123};

            // Сортировка массива
            
            int[] result = MyMergeSort.MergeSort(array);

            for (int i = 0; i < result.Length; i++)
            {
               Console.WriteLine(result[i]); 
            }

        }

    }
}
