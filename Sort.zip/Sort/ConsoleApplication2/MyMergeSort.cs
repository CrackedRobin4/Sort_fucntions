namespace MergeSort
{
    public class MyMergeSort
    {
        public static int[] MergeSort(int[] array)
        {
            if (array.Length <= 1)
            {
                return array;
            }
            else
            {
                int mid = array.Length / 2;
                int[] left = new int[mid];
                int[] right = new int[array.Length - mid];
                for (int i = 0; i < mid; i++)
                {
                    left[i] = array[i];
                }

                int count = 0;
                for (int i = mid; i < array.Length; i++)
                {
                    right[count] = array[i];
                    count++;
                }

                left = MergeSort(left);
                right = MergeSort(right);
                return MyMerge(left, right);
            }
        }

        private static int[] MyMerge(int[] left, int[] right)
        {
            int[] result = new int[left.Length + right.Length];
            int k = 0, i = 0, j = 0;
            while (true)
            {
                if (k == result.Length)
                {
                    return result;
                }
                while (left[i] < right[j])
                {
                    result[k] = left[i];
                    i++;
                    k++;
                    if (i == left.Length)
                    {
                        while (j != right.Length)
                        {
                            result[k] = right[j];
                            j++;
                            k++;
                        }

                        return result;
                    }
                }

                while (right[j] <= left[i])
                {
                    result[k] = right[j];
                    j++;
                    k++;
                    if (j == right.Length)
                    {
                        while (i != left.Length)
                        {
                            result[k] = left[i];
                            i++;
                            k++;
                        }

                        return result;
                    }
                }
            }
        }
    }
}